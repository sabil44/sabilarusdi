<?php
	$hostname = 'localhost';
	$username = 'root';
	$pasword = '';
	$dbname = 'website_galeri_foto';

	$conn = mysqli_connect($hostname, $username, $pasword, $dbname) or die ('gagal terhubung ke database');
	?>